#include "TitleScene.h"

HRESULT TitleScene::Init()
{
	return E_NOTIMPL;
}

void TitleScene::Release()
{
}

void TitleScene::Update()
{
}

void TitleScene::Render(HDC hdc)
{
}

void TitleScene::PressZKey()
{
}
